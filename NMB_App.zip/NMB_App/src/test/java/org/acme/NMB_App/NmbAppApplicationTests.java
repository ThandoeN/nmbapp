package org.acme.NMB_App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NmbAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
