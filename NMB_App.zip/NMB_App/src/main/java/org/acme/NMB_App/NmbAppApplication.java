package org.acme.NMB_App;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NmbAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(NmbAppApplication.class, args);
	}

}
